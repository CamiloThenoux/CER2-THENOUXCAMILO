from django.db import models
from django.contrib.auth.models import User


    
   
tipo_mensajes=[
    ("Consulta Academica","Consulta Academica"),
    ("Consulta Practica","Consulta Practica"),
    ("Oferta Practica","Oferta Practica"),
]
    

class Mensaje(models.Model):
    Nombree= models.CharField(max_length=50)
    tipo= models.CharField(max_length=50,choices=tipo_mensajes)
    alumno= models.CharField(max_length=50)
    profesor=models.CharField(max_length=50)
    informacion=models.CharField(max_length=300)
    def __str__(self) -> str:
        return self.Nombree
    