from django.contrib import admin


from .models import Mensaje

admin.site.register(Mensaje)
# Register your models here.
