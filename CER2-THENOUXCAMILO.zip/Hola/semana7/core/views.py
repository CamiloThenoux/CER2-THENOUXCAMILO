from django.shortcuts import render, redirect
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.decorators import login_required


from .models import Mensaje
from django.shortcuts import render
from django.contrib.auth.decorators import login_required

def index(request):
    return render(request,'core/index.html')


def listar(request):
        lista_proyectos= Mensaje.objects.all()
   

        data={
             "lista_proyectos": lista_proyectos,
        }
        
        return render(request,'core/proyectos.html',data)

@login_required
def home_view(request):
    return render(request, 'core/base.html')


   
def iniciarsesion(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request=request,username=username, password=password)
        
        if user is not None:
            login(request, user)
            return redirect('/proyectos')
        else:
            return render(request, 'core/proyectos.html')
    else:
        return render(request, 'core/iniciarsesion.html')
    
@login_required 
def logout_view(request):
        logout(request)
        return redirect('/')

def nuevo_proyecto(request):
    return render(request, 'core/nuevo_proyecto.html')

def agregar_proyecto(request):
        if(request.POST):
            nombre= request.POST['txtNombreproyecto']
            estudiante=request.POST['txtNombrestudiante']
            tipo= request.POST['cboTipo']
            profesor=request.POST['txtprofesor']
            informacion=request.POST['txtinformacion']            
            #validaciones de reglas de negocio
                
            #construyo y cargar el objeto con los datos del form 
            mensaje=Mensaje()
            mensaje.Nombree=nombre
            mensaje.alumno=estudiante
            mensaje.tipo=tipo
            mensaje.profesor=profesor
            mensaje.informacion=informacion
            #guardar cambio en la base de datos
            mensaje.save()

        return render(request,'core/nuevo_proyecto.html')
def patrocinado(request):
     lista_proyectos= Mensaje.objects.all()
     data={
             "lista_proyectos": lista_proyectos,
        }
     return render(request, 'core/patrocinado.html', data)
def sin_patrocinado(request):
     lista_proyectos= Mensaje.objects.all()
     data={
             "lista_proyectos": lista_proyectos,
        }
     return render(request, 'core/sin_patrocinio.html', data)
def tema1(request):
     lista_proyectos= Mensaje.objects.all()
     data={
             "lista_proyectos": lista_proyectos,
        }
     return render(request, 'core/tema1.html', data)
def tema2(request):
     lista_proyectos= Mensaje.objects.all()
     data={
             "lista_proyectos": lista_proyectos,
        }
     return render(request, 'core/tema2.html', data)
def tema3(request):
     lista_proyectos= Mensaje.objects.all()
     data={
             "lista_proyectos": lista_proyectos,
        }
     return render(request, 'core/tema3.html', data)